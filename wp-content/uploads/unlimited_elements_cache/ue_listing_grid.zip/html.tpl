<div class="ue-grid uc-items-wrapper{{uc_filtering_addclass}}{{remote_parent.class}} uc-dynamic-popup-grid" id="{{uc_id}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}} data-template-id="{{listing_templateid}}">
  {{put_items()}}
</div>

{% if show_empty_message == "true" %}

	{% if empty_message_type == "message" %}
    	<div id="{{uc_id}}_empty_message" class="ue-no-posts-found" {% if uc_num_items > 0 %} style="display:none" {% endif %}>{{no_posts_found|raw}}</div>
	{% elseif empty_message_type == "template" %}
		{{putElementorTemplate(no_posts_found_template_templateid)}}
	{% endif %}

{% endif %}