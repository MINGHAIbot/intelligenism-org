#{{uc_id}} {	
  	{% if grid_type == "masonry" %}
      padding: 0;
 	  position:relative;
    {% else %}
      display: grid;
    {% endif %}
}

#{{uc_id}} .ue-grid-item{
	box-sizing: border-box;
    overflow:hidden;
    {% if grid_type == "masonry" %}
        display: block;
        width: 100%;
        position:absolute;   
    {% endif %}	

    {% if grid_type == "regular" %}

    {% endif %}
}

{% if equal_height == "true" %}
  #{{uc_id}} .ue-grid-item > *,
  #{{uc_id}} .ue-grid-item > * > *{
    height: 100%;
  }
{% endif %}

{% if grid_type == "masonry" %}
@media screen and (max-width: 767px) {
  #{{uc_id}}{    
    min-width: unset !important;
  }
  #{{uc_id}} .ue-grid-item{
  	max-width: 100%;
  }
}
{% endif %}