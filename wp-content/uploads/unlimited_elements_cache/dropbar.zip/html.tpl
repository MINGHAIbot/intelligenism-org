{# twig vars #}{##}
{% set iconElem %}<span class="ue-drop-icon-inactive">{{icon_html|raw}}</span>{% if different_active_icon == "true" %}<span class="ue-drop-icon-active">{{icon_active_html|raw}}</span>{% endif %}{% endset %}
{# end twig vars #}{##}

<div id="{{uc_id}}" class="ue-dropbar" data-source="{{content_type}}" data-element-id="{{element_id|raw}}" data-show-errors="{{show_errors}}" data-hide-connected-elements="{{hide_connected_element_in_the_editor}}" data-editor="{{uc_inside_editor}}">
  
    <button class="ue-dropbar-button {{hover_animation}}" aria-expanded="false" aria-controls="{{ uc_id }}-content" type="button">
      {% if show_icon == "before" %}{{iconElem}}{% endif %}
      {{button_title|raw}}
      {% if show_icon == "after" %}{{iconElem}}{% endif %}
    </button>

  <div id="{{ uc_id }}-content" class="ue-dropbar-content" hidden>

    {% if content_type == "text" %}
      {{text_content_editor|raw}}
    {% endif %}
      
    {% if content_type == "image" %}
      <img src="{{image}}" {{image_attributes|raw}} caption="{{image_caption}}">
    {% endif %}
    
    {% if content_type == "template" %}
      <div class="ue-dropbar-template">{{putElementorTemplate(template_templateid)}}</div>
    {% endif %}
  </div>
  
</div>