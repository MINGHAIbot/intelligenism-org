{{ ucfunc("put_docready_start") }}

  var objGrid = jQuery("#{{uc_id}}");

  {% if directional_hover == "true" %}  
  	var objItem = objGrid.find(".ue-item");
   
  	objItem.directionalHover();
   
    objGrid.on("uc_ajax_refreshed",function(){      
     	objItem = objGrid.find(".ue-item");
   
  		objItem.directionalHover();         
  	});  
  {% endif %}
  
  {% if show_view_switcher == "true" %}
    var objSwitchers = objGrid.find(".view-switcher-icon");
    var objGridContainer = objGrid.find(".ue-woo-grid")
    var gridModeClass = "view-switcher-grid-icon";
    var listModeClass = "view-switcher-list-icon";
    var hiddenClass = "ue-hidden";
    var listViewClass = "ue-list-view";
    var objGridView = objGrid.find("."+gridModeClass);
    var objListView = objGrid.find("."+listModeClass);
   
    /**
    * force grid view
    */
	function forceGridView(){
      objGridContainer.css("grid-template-columns", "");
 
      if("{{layout}}" != "side_by_side")
        objGrid.removeClass(listViewClass);
    }
   
    /**
    * force list view
    */
	function forceListView(){
      objGridContainer.css("grid-template-columns", "repeat(1, 1fr)");
 
      objGrid.addClass(listViewClass);
    }
   
    /**
    * on switcher icon click
    */
    function onSwitcherIconClick(){
      var objIcon = jQuery(this);
      var isGridMode = objGridView.hasClass(hiddenClass);//if grid mode then grid icon is hidden
      
      if(isGridMode == true){
        objGridView.removeClass(hiddenClass);
        objListView.addClass(hiddenClass);
        
        forceListView();
      }else{
        objGridView.addClass(hiddenClass);
        objListView.removeClass(hiddenClass);
        
        forceGridView();
      }
    }
   
    objSwitchers.on("click", onSwitcherIconClick);
  {% endif %}

  {% if remote_parent.attributes is not empty %}

     var objRemoteOptions = {
          class_items:"ue-item",
          class_active:"ue-active-item",
          add_set_active_code:true
      };

      {{ucfunc("put_remote_parent_js","objGrid","objRemoteOptions")}}  

  {% endif %}

{{ ucfunc("put_docready_end") }}