<div id="{{uc_id}}" class="uc_post_grid_style_one{{uc_filtering_addclass}}{{remote_parent.class}} {{uc_dynamic_popup_class}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}}>
  {% if show_view_switcher == "true" %}
    <div class="view-switcher">
      <div class="view-switcher-button">
        <div class="view-switcher-icon view-switcher-grid-icon ue-hidden">{{grid_view_icon_html|raw}}</div>
      </div>
      <div class="view-switcher-button">
        <div class="view-switcher-icon view-switcher-list-icon">{{list_view_icon_html|raw}}</div>
      </div>
    </div>
  {% endif %}	
  <div class="uc_post_grid_style_one_wrap ue_post_grid uc-items-wrapper ue-woo-grid">
    {{put_items()}}
  </div>
</div>

{% if show_empty_message == "true" %}
  <div id="{{uc_id}}_empty_message" class="ue-no-posts-found" {% if uc_num_items > 0 %} style="display:none" {% endif %}>{{no_posts_found|raw}}</div>
{% endif %}