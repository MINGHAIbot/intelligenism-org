#{{uc_id}}.uc_animated_hamburger_icon_holder{ 
  position: relative;
  z-index: {{z_index}};
}

#{{uc_id}} .uc_hamburger{
  display: inline-block;  
}

#{{uc_id}} .uc_animated_hamburger_icon {
    transition: background-color .3s;
  	text-align: {{alignment}};
}