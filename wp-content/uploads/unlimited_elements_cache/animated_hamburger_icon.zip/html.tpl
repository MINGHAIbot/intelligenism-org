<div id="{{uc_id}}" class="uc_animated_hamburger_icon_holder" style="text-align: {{alignment}};">
  
  <a id="{{hamburger_close_trigger}}" class='uc-icon-close-trigger' href="javascript:void(0)" style='display:none' role="button" aria-label="Close Menu">Close Trigger</a>
  
  <a href="{{link}}" {{link_html_attributes|raw}} class="uc_animated_hamburger_icon" role="button" aria-label="Open Menu" aria-expanded="false">

     <div class="uc_hamburger" id="{{effects}}">
      <span class="uc_line" aria-hidden="true"></span>
      <span class="uc_line" aria-hidden="true"></span>
      <span class="uc_line" aria-hidden="true"></span>
    </div>

  </a>
</div>