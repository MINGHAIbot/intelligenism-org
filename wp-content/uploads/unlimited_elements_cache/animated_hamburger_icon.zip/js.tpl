{{ ucfunc("put_docready_start") }}
    	
  var objIcon = jQuery("#{{uc_id}}");  
  var objLink = jQuery("#{{uc_id}} .uc_animated_hamburger_icon");  
  var link = objLink.prop("href");
  
  link = decodeURIComponent(link);
   
  var isPopupAction = (link.indexOf("elementor-action:action=popup") != -1);
  
  var objLinkCloseTrigger = objIcon.find(".uc-icon-close-trigger");
  var objHamburger = jQuery("#{{uc_id}} .uc_hamburger");
  
  var classActive = "is-active";
  
  objLinkCloseTrigger.on("click", function(){
    
	 objHamburger.removeClass(classActive);
     objLink.removeClass(classActive);
    
  });
  
  objLink.click(function(){
    	
    	//trigger custom popup event to open accordion widget
    	jQuery('body').trigger('uc_burger_popup_open');
    
    	objHamburger.toggleClass(classActive);
    	objLink.toggleClass(classActive);
    
    	if(objLink.hasClass(classActive) == true)
          objLink.attr('aria-expanded', true);
    	else
          objLink.attr('aria-expanded', false);    
  });
  
  if(isPopupAction == true){
	 
	jQuery( document ).on( 'elementor/popup/hide', (event, id) => {	
		setTimeout(function(){
			objHamburger.removeClass(classActive);
          	objLink.removeClass(classActive);
		},300);
      
	});	
  }
    	
{{ ucfunc("put_docready_end") }}