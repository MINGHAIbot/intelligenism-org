<div id="{{uc_id}}" class="ue-line-text-devider">
  <div class="blox_hr_txt">{{text|raw}}</div>
  <div class="blox_hr"></div>
</div>