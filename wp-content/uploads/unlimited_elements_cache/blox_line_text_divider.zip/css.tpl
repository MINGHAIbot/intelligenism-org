#{{uc_id}} {
  min-height: 1px;
  position: relative;
  text-align: {{align}};
}

#{{uc_id}} .blox_hr{
  display:inline-block;
  position: absolute;
  top: 50%;
  {% if align == "left" %}
  left: 0;
  transform: translate(0, -50%);
  {% elseif align == "center" %}
  left: 50%;
  transform: translate(-50%, -50%);
  {% elseif align == "right" %}
  right: 0;
  transform: translate(0, -50%);
  {% endif %}
}

#{{uc_id}} .blox_hr_txt{
  display: inline-block;
  position: relative;
  z-index: 1;
  margin: 0;
  text-align: center;
}